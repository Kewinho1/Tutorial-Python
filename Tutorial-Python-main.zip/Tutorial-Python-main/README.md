# Tutorial-Python

Kewin Lorente Magoga - 2403809

Livia Ferreira Rodrigues - 2408713

Gustavo Brandão Schenkel - 2401391

Gustavo Mattioli Santana - 2403394

Marcos Farinha Prado - 2403541

Alessandra de Freitas Bichara - 2405879

Joao Vitor Casote -  2403652
